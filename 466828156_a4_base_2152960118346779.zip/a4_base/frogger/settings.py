settings = {
    'use_graphics': True
}
